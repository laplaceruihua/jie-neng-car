#ifndef _SHANGWEIJI_H
#define _SHANGWEIJI_H
#include"common.h"
void sendDataToScope(void);
void push(uint8 chanel,uint16 data);
#endif
