#ifndef __INIT_H_
#define __INIT_H_


void peripheral_init(void);
void parameter_init(void);
#endif  //__INIT_H_