#ifndef _fun_h
#define _fun_h

#include "include.h"


void  delay_ms(long t);
int   mylabs(int  temp_data);
int16 myabs(int16 temp_data);
int   limit(int x, int y);
int   limit_ab(int x, int a, int b);


















#endif 