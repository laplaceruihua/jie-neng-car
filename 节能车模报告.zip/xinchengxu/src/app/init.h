#ifndef __INIT_H_
#define __INIT_H_


 float DirControl_P_wan ;
 float DirControl_D_wan ;
 float DirControl_P_huan ;
 float DirControl_D_huan ;

void peripheral_init(void);
void parameter_init(void);
#endif  //__INIT_H_