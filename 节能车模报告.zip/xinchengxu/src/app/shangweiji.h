#ifndef _SHANGWEIJI_H
#define _SHANGWEIJI_H
#include"common.h"
void sendDataToScope(void);
void push(uint8 chanel,uint16 data);

/*
void CRC16(unsigned char *Array,unsigned char *Rcvbuf,unsigned int Len);
void sendscope(short int ch1,short int ch2,short int ch3,short int ch4);//ʾ�������ͺ���

*/
#endif
