#ifndef __MOTOR_H_
#define __MOTOR_H_

uint16 abs_jdz(int X);
void motor_control(void);
void steering_control(void);


#endif  //__INIT_H_
